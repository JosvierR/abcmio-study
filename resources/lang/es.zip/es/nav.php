<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Properties Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'header' => [
        'nav' => [
            'login' => 'Ingresar',
            'register' => 'Registro',
            'reports' => 'Denuncias',
            'directory' => 'Directorio',
            'my-ads' => 'Mis Anuncios',
            'buy-credits' => 'Compra Créditos',
            'add-ad' => 'Nuevo anuncio',
            'credits' => 'Créditos',
            'sell-credits' => 'Vender Créditos',
            'admin' =>
                [
                    'title'=>'Administrador',
                    'credit'=>'Administrar Créditos.',
                ],
        ]
    ],
    'footer' => [
        'term_and_conditions' => 'Términos y Condiciones'
    ]

];
